Instructor Demo

## Reference

* Jay, C. V., Quakenbush, L. T., Citta, J. J., Fischbach, A. S. and Battaile, B. C., 2020, Sex and Age Composition of Walrus Groups Hauled Out on Ice Floes in the Bering and Chukchi Seas, 2013-2015: U.S. Geological Survey data release, [https://doi.org/10.5066/F79K4894](https://doi.org/10.5066/F79K4894).

---

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
